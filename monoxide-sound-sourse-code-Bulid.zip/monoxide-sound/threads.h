#pragma once
#include "monoxide-sound.h"

VOID
WINAPI
TimerThread(
	VOID
);