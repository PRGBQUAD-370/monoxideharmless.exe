#pragma once
#include "monoxide-sound.h"

typedef VOID( WINAPI AUDIO_SEQUENCE )(
	_In_ INT nSamplesPerSec,
	_In_ INT nSampleCount,
	_Inout_ PSHORT psSamples
	), *PAUDIO_SEQUENCE;

typedef VOID( WINAPI AUDIOSEQUENCE_OPERATION )(
	_In_ INT nSamplesPerSec
	), *PAUDIO_SEQUENCE_OPERATION;

typedef struct tagAUDIO_SEQUENCE_PARAMS
{
	INT nSamplesPerSec;
	INT nSampleCount;
	PAUDIO_SEQUENCE pAudioSequence;
	PAUDIO_SEQUENCE_OPERATION pPreAudioOp;
	PAUDIO_SEQUENCE_OPERATION pPostAudioOp;
} AUDIO_SEQUENCE_PARAMS, *PAUDIO_SEQUENCE_PARAMS;